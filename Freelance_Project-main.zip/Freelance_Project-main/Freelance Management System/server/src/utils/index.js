const CustomException = require('./CustomException');

module.exports = {
    CustomException
}